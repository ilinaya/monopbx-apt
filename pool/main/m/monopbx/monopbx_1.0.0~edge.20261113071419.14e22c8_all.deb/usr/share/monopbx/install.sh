#!/usr/bin/env bash
# MonoPbx VM installer (W4-DEP-04). Ubuntu 24.04 LTS ONLY (DECISIONS Round 5), Docker Compose under the hood.
#
#   curl -fsSL https://get.mpbx.ilinaia.com/install.sh | sudo bash
#   curl -fsSL https://get.mpbx.ilinaia.com/install.sh | sudo bash -s -- --domain pbx.example.com --accept-acme-terms
#
# (get.mpbx.ilinaia.com is a placeholder: the real download domain is still open, Q-ACCT-03.)
#
# What it does, in order, and stops at the first problem:
#   1. preflight: Ubuntu 24.04, amd64/arm64, systemd, CPU/RAM/disk, clock (NTP), free ports, a terminal, public IP, DNS
#   2. Docker Engine + Compose plugin from Docker's official apt repository (key fingerprint pinned and verified)
#      unless a working Docker is already there
#   3. downloads the release bundle, verifies its SHA-256, installs it to /opt/mpbx
#   4. writes the settings into /opt/mpbx/compose/prod/.env (0600), runs `mpbx init`: the RECOVERY KEY is shown once
#      and you must re-type a group of it to prove you saved it; nothing is written before that
#   5. installs /etc/systemd/system/mpbx.service and /usr/local/sbin/mpbx-ctl, starts the stack, runs the selftest
#   6. prints the first-administrator setup URL (from `mpbx init`) and the firewall rules to open
#
# Re-running is safe: every step converges, secrets are never regenerated or changed, nothing is deleted.
# Remove it with `sudo mpbx-ctl uninstall` (data is kept unless you ask for it and confirm).
#
# Options
#   --domain FQDN            public name (DNS must point at this server); enables ACME when the terms are accepted
#   --no-acme                never use ACME and do not ask (self-signed / Caddy's internal CA)
#   --accept-acme-terms      accept the ACME CA's subscriber agreement (Let's Encrypt by default)
#   --acme-email ADDRESS     contact for expiry notices from the CA
#   --acme-directory URL     ACME directory (default Let's Encrypt production)
#   --public-ip IP           this server's public IPv4 (skips the lookup of checkip.amazonaws.com and pins it: the
#                            15-minute public address check, mpbx-public-ip.timer, then leaves it alone)
#   --turn | --no-turn       run coturn (customer-run TURN for remote softphones behind strict NAT or firewalls) and
#                            hand its STUN/TURN URLs to the clients | stop doing so. A re-run keeps the earlier choice.
#   --observability | --no-observability   run Prometheus + Grafana with the MonoPbx dashboards (Grafana on
#                            127.0.0.1:3000 only: reach it with an SSH tunnel or your reverse proxy) | stop doing so.
#                            A re-run keeps the earlier choice. Needs internet once (the ClickHouse plugin).
#   --front caddy | --front none   (FU-FIX-WSS-PROXY-2) put Caddy on 80/443 in front of mpbx: it gets the web certificate
#                            (ACME with --accept-acme-terms and --acme-email, else its own internal CA), proxies
#                            wss://<host>/sip to the SIP edge for the web softphone, and the edge also serves SIP over
#                            TLS on 5061 (certificate from the PBX store). Without --domain the name is
#                            <a-b-c-d>.sslip.io. A re-run keeps the earlier choice. The Debian package uses it.
#                            DEFAULT (FU-INST-FRONT-NONE-1): a fresh install with TLS on gets --front caddy, so
#                            wss://<host>/sip works out of the box; a re-run keeps the earlier choice (an install made
#                            before this default stays on none until you pass --front caddy).
#                            --front none: mpbx serves 80/443 itself (no WSS); it STOPS AND REMOVES a Caddy left by an
#                            earlier --front caddy run (its certificate volumes are kept). Not with --no-tls.
#   --media-stream | --no-media-stream   (FU-W9-AI-06-5d) publish mpbx-media's AI media stream listener as
#                            wss://<front site>/v1/media-stream (writes MPBX_MEDIA_STREAM_URL into .env, so mpbx-ctl adds
#                            compose.media-stream.yaml) | stop doing so. Needs the Caddy front: the route is Caddy's, so
#                            --front none and --no-tls are refused. A re-run keeps the earlier choice.
#   --bridge-network NAME    (FU-INST-BRIDGE-2) the Docker network whose gateway that is, when the host's default bridge
#                            network is not called `bridge` (also MPBX_BRIDGE_NETWORK). Prometheus then scrapes the
#                            host-network services at the same address (MPBX_METRICS_BIND).
#   --bridge-gateway IP      (FU-INST-BRIDGE-1) the Docker bridge gateway address the engine uses to reach rtpengine and
#                            mpbx-media on the host. Default: detected with `docker network inspect bridge` (custom
#                            bip, daemon.json, any subnet); rootless Docker is refused (it has no host bridge).
#   --relay-url URL | --no-relay   (with --front caddy) the push relay the install enrolls with (default: the MonoPbx
#                            relay) | do not enroll (mobile apps then ring only in the foreground)
#   --no-tls | --tls         do not publish 80/443 (HTTP on 8080 for a proxy you run) | publish them (default)
#   --http-port PORT         the plain API/web port (default 8080; loopback only while TLS is on)
#   --channel stable|beta|nightly   release channel (default stable)        --version X.Y.Z  an exact release
#   --unattended             no terminal needed: the recovery key is printed ONCE to stdout and cannot be
#                            confirmed, so capture it from the console safely. Implies --yes.
#   --country CC             the company's home country (ISO 3166-1 alpha-2, for example MX or ES): the console's setup
#                            wizard preselects it in the required country step (dial plan and time zone follow it).
#                            Stored as MPBX_SETUP_COUNTRY in .env; a re-run without it keeps the earlier value.
#   --yes                    do not ask "continue?"
#   --skip-dns-check         continue even if --domain does not resolve to this server yet
#   --multi-company          host several companies (W10-TEN-04): each company gets <handle>.<--domain> as its web
#                            address, SIP domain and realm. Needs --domain and a wildcard DNS record
#                            *.<--domain> pointing at this server. Stored once in the database; a re-run keeps it.
#   --ipv6 | --no-ipv6       dual stack (W10-NET-01): rtpengine also binds RTP on this server's global IPv6 address
#                            (RTPE_INTERFACE6, detected) | IPv4 media only. A re-run keeps the earlier choice. Give
#                            --domain an AAAA record too (docs/guides/ipv6-codecs-qos.md).
#   --calls N                plan for N concurrent relayed calls on this server (FU-W5QA04-3): rtpengine needs 4 UDP
#                            ports per call, so the RTP range is sized to 30000 .. 30000+4N (never below the default
#                            30000-40000 = 2,500 calls, at most N=4750 so it stays clear of the TURN range). A re-run
#                            keeps the earlier range unless this is given. `mpbx sizing --concurrent-calls N` says what
#                            CPU that many calls need.
#   --force-bundle           replace the installed bundle files by a different version WITHOUT a snapshot
#                            (upgrade with `mpbx-ctl upgrade` instead: snapshot, checks and rollback)
#   --skip-resource-checks   ignore CPU/RAM/disk minimums (testing only)
#   --docker-only            install Docker (verified repository) and stop
#   --air-gapped             this server has no internet: never download Docker; use the third-party images you loaded
#                            with `docker load` by their tags (compose.airgap.yaml); pair with MPBX_BUNDLE_FILE and
#                            --public-ip (docs: site/docs/operators/air-gapped-install.md)
#   uninstall [...]          hands over to `mpbx-ctl uninstall`
#
# Environment (all optional)
#   MPBX_BASE_URL            download base (default https://get.mpbx.ilinaia.com; http only for 127.0.0.1/localhost)
#   MPBX_BUNDLE_FILE         install this local bundle tarball instead of downloading it (also MPBX_BUNDLE_SHA256)
#   MPBX_IMAGE, MPBX_RTPENGINE_IMAGE, MPBX_MEDIA_IMAGE   override the image references from the bundle (pin by
#                            digest); MPBX_MEDIA_IMAGE is the mpbx-media service (MVP-GAP-02)
#
# NEVER run this on a workstation: it installs packages, writes /etc and starts services. It refuses anything that
# is not Ubuntu 24.04 on Linux.
#
# The whole script is one function called on the last line, so a truncated download runs nothing.
set -euo pipefail

BASE_URL_DEFAULT="https://get.mpbx.ilinaia.com"
ROOT=/opt/mpbx
PROD="$ROOT/compose/prod"
UNIT=/etc/systemd/system/mpbx.service
LINK=/usr/local/sbin/mpbx-ctl
# Docker's published apt signing key (https://docs.docker.com/engine/install/ubuntu/). Pinned: the key file that
# is downloaded must contain exactly this fingerprint or nothing is installed.
DOCKER_KEY_FPR="9DC858229FC7DD38854AE2D88D81803C0EBFCD88"
DOCKER_KEY_URL="https://download.docker.com/linux/ubuntu/gpg"
MIN_CPUS=2
MIN_RAM_KB=3800000      # "4 GB" machines report about 3.8 million kB
MIN_DISK_GB=20          # research 08; databases and recordings grow, size the disk for your retention

# ---- output -------------------------------------------------------------------------------------------------------
say()  { printf '==> %s\n' "$*"; }
info() { printf '    %s\n' "$*"; }
warn() { printf 'WARNING: %s\n' "$*" >&2; }
die()  { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

# ---- options ------------------------------------------------------------------------------------------------------
TLS_FLAG_GIVEN="" DOMAIN_FLAG="" BUNDLE_VERSION="" BUNDLE_DIR="" WORK=""
DOMAIN="" ACME_TERMS=0 ACME_EMAIL="" ACME_DIR="https://acme-v02.api.letsencrypt.org/directory"
PUBLIC_IP="" TLS_MODE="" HTTP_PORT="" CHANNEL=stable VERSION="" UNATTENDED=0 YES=0
FRONT="" RELAY_URL="" NO_RELAY=0 BRIDGE_GW="" BRIDGE_NET="${MPBX_BRIDGE_NETWORK:-bridge}" FRONT_DEFAULTED=0
SKIP_DNS=0 FORCE_BUNDLE=0 SKIP_RES=0 DOCKER_ONLY=0 AIRGAP=0 TURN_MODE="" OBS_MODE="" MEDIA_STREAM="" IPV6_MODE="" CALLS="" MULTI_COMPANY=0 COUNTRY=""

usage() {
  if [ -r "${BASH_SOURCE[0]:-}" ]; then
    sed -n '2,/^# The whole script/p' "${BASH_SOURCE[0]}" | sed '$d' | sed 's/^# \{0,1\}//'
  else
    echo "see https://get.mpbx.ilinaia.com/install.sh or the header of deploy/installer/install.sh"
  fi
}

parse_args() {
  while [ "$#" -gt 0 ]; do
    case "$1" in
      --domain) DOMAIN="${2:?--domain needs a value}"; DOMAIN_FLAG=1; shift ;;
      --domain=*) DOMAIN="${1#*=}"; DOMAIN_FLAG=1 ;;
      --accept-acme-terms) ACME_TERMS=1 ;;
      --no-acme) ACME_TERMS=-1 ;;
      --acme-email) ACME_EMAIL="${2:?--acme-email needs a value}"; shift ;;
      --acme-email=*) ACME_EMAIL="${1#*=}" ;;
      --acme-directory) ACME_DIR="${2:?--acme-directory needs a value}"; shift ;;
      --acme-directory=*) ACME_DIR="${1#*=}" ;;
      --public-ip) PUBLIC_IP="${2:?--public-ip needs a value}"; shift ;;
      --public-ip=*) PUBLIC_IP="${1#*=}" ;;
      --front) FRONT="${2:?--front needs caddy or none}"; shift ;;
      --front=*) FRONT="${1#*=}" ;;
      --bridge-gateway) BRIDGE_GW="${2:?--bridge-gateway needs an IPv4 address}"; shift ;;
      --bridge-gateway=*) BRIDGE_GW="${1#*=}" ;;
      --bridge-network) BRIDGE_NET="${2:?--bridge-network needs a Docker network name}"; shift ;;
      --bridge-network=*) BRIDGE_NET="${1#*=}" ;;
      --relay-url) RELAY_URL="${2:?--relay-url needs a value}"; shift ;;
      --relay-url=*) RELAY_URL="${1#*=}" ;;
      --no-relay) NO_RELAY=1 ;;
      --no-tls) TLS_MODE=off; TLS_FLAG_GIVEN=1 ;;
      --tls) TLS_MODE=on; TLS_FLAG_GIVEN=1 ;;
      --http-port) HTTP_PORT="${2:?--http-port needs a value}"; shift ;;
      --http-port=*) HTTP_PORT="${1#*=}" ;;
      --channel) CHANNEL="${2:?--channel needs a value}"; shift ;;
      --channel=*) CHANNEL="${1#*=}" ;;
      --version) VERSION="${2:?--version needs a value}"; shift ;;
      --version=*) VERSION="${1#*=}" ;;
      --unattended) UNATTENDED=1; YES=1 ;;
      --yes|-y) YES=1 ;;
      --skip-dns-check) SKIP_DNS=1 ;;
      --multi-company) MULTI_COMPANY=1 ;;
      --country) COUNTRY="${2:?--country needs a two-letter country code (for example MX)}"; shift ;;
      --country=*) COUNTRY="${1#*=}" ;;
      --force-bundle) FORCE_BUNDLE=1 ;;
      --skip-resource-checks) SKIP_RES=1 ;;
      --docker-only) DOCKER_ONLY=1 ;;
      --air-gapped) AIRGAP=1 ;;
      --turn) TURN_MODE=on ;;
      --no-turn) TURN_MODE=off ;;
      --observability) OBS_MODE=on ;;
      --no-observability) OBS_MODE=off ;;
      --media-stream) MEDIA_STREAM=on ;;
      --no-media-stream) MEDIA_STREAM=off ;;
      --ipv6) IPV6_MODE=on ;;
      --no-ipv6) IPV6_MODE=off ;;
      --calls) CALLS="${2:?--calls needs a value}"; shift ;;
      --calls=*) CALLS="${1#*=}" ;;
      -h|--help) usage; exit 0 ;;
      *) die "unknown option: $1 (see --help)" ;;
    esac
    shift
  done
  case "$CHANNEL" in stable|beta|nightly) ;; *) die "--channel must be stable, beta or nightly" ;; esac
  [[ -z "$VERSION" || "$VERSION" =~ ^[0-9A-Za-z][0-9A-Za-z._+-]*$ ]] || die "--version has an unexpected format"
  [[ -z "$CALLS" || "$CALLS" =~ ^[0-9]+$ ]] || die "--calls must be a number"
  if [ -n "$CALLS" ] && { [ "$CALLS" -lt 1 ] || [ "$CALLS" -gt 4750 ]; }; then
    die "--calls must be 1 to 4750: one server's RTP range (4 ports per call) must stay below the TURN range 49160-49200; use more than one media node beyond that"
  fi
  [[ -z "$COUNTRY" || "$COUNTRY" =~ ^[A-Za-z]{2}$ ]] || die "--country must be a two-letter ISO 3166-1 country code (for example MX)"
  COUNTRY="$(printf '%s' "$COUNTRY" | tr '[:lower:]' '[:upper:]')"
  [[ -z "$HTTP_PORT" || "$HTTP_PORT" =~ ^[0-9]+$ ]] || die "--http-port must be a number"
  [[ -z "$DOMAIN" || "$DOMAIN" =~ ^[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?$ ]] || die "--domain is not a valid host name"
  [[ -z "$PUBLIC_IP" || "$PUBLIC_IP" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || die "--public-ip must be an IPv4 address"
  [[ -z "$ACME_EMAIL" || "$ACME_EMAIL" =~ ^[^[:space:]@]+@[^[:space:]@]+$ ]] || die "--acme-email is not an e-mail address"
  [[ "$ACME_DIR" =~ ^https://[^[:space:]]+$ ]] || die "--acme-directory must be an https:// URL"
  if [ -n "$DOMAIN" ] && [ "$TLS_MODE" = off ]; then die "--domain needs TLS; drop --no-tls"; fi
  case "$FRONT" in ""|caddy|none) ;; *) die "--front must be caddy or none" ;; esac
  if [ "$FRONT" = caddy ] && [ "$TLS_MODE" = off ]; then die "--front caddy serves HTTPS; drop --no-tls"; fi
  if [ "$MEDIA_STREAM" = on ]; then
    [ "$FRONT" != none ] || die "--media-stream needs the Caddy front (the /v1/media-stream route is Caddy's); drop --front none"
    [ "$TLS_MODE" != off ] || die "--media-stream serves wss://; drop --no-tls"
  fi
  [[ -z "$BRIDGE_GW" || "$BRIDGE_GW" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || die "--bridge-gateway must be an IPv4 address"
  [[ "$BRIDGE_NET" =~ ^[A-Za-z0-9][A-Za-z0-9_.-]*$ ]] || die "--bridge-network must be a Docker network name"
  [[ -z "$RELAY_URL" || "$RELAY_URL" =~ ^https://[^[:space:]]+$ ]] || die "--relay-url must be an https:// URL"
  if [ "$MULTI_COMPANY" -eq 1 ] && [ -z "$DOMAIN" ]; then die "--multi-company needs --domain (companies live at <handle>.<domain>)"; fi
}

# ---- helpers ------------------------------------------------------------------------------------------------------
have() { command -v "$1" >/dev/null 2>&1; }
has_tty() { ( : </dev/tty ) 2>/dev/null; }

ask_yes() { # ask_yes "question" -> 0 on yes. Without a terminal the answer is no.
  [ "$YES" -eq 0 ] || return 0
  has_tty || return 1
  local a; read -r -p "$1 [y/N] " a </dev/tty || return 1
  case "$a" in y|Y|yes|YES) return 0 ;; *) return 1 ;; esac
}

# Like ask_yes, but --yes does not answer it: consent to a third party's terms is given in person or by its own flag.
ask_explicit() {
  has_tty || return 1
  local a; read -r -p "$1 [y/N] " a </dev/tty || return 1
  case "$a" in y|Y|yes|YES) return 0 ;; *) return 1 ;; esac
}

env_get() { sed -n "s/^$1=\(.*\)$/\1/p" "$PROD/.env" 2>/dev/null | tail -n1; }

# Set KEY=VALUE in .env: replace the first (possibly empty) assignment, else append. The value travels through the
# environment, never a command line, and is never printed.
env_set() {
  local key="$1" val="$2" tmp
  tmp="$(mktemp "$PROD/.env.XXXXXX")"
  chmod 600 "$tmp"
  KEY="$key" VAL="$val" awk '
    BEGIN { k = ENVIRON["KEY"]; v = ENVIRON["VAL"]; done = 0 }
    index($0, k "=") == 1 && !done { print k "=" v; done = 1; next }
    { print }
    END { if (!done) print k "=" v }' "$PROD/.env" >"$tmp"
  mv "$tmp" "$PROD/.env"
}

is_private_ip() {
  local ip="$1" a b
  IFS=. read -r a b _ _ <<<"$ip"
  case "$a" in
    10|127) return 0 ;;
    192) [ "$b" = 168 ] ;;
    172) [ "$b" -ge 16 ] && [ "$b" -le 31 ] ;;
    169) [ "$b" = 254 ] ;;
    100) [ "$b" -ge 64 ] && [ "$b" -le 127 ] ;;
    *) return 1 ;;
  esac
}

port_busy() { # port_busy tcp|udp PORT
  local proto="$1" port="$2" flag=-ltn
  [ "$proto" = udp ] && flag=-lun
  ss -H "$flag" 2>/dev/null | awk '{print $4}' | grep -Eq "[:.]$port\$"
}

# ---- 1. preflight -------------------------------------------------------------------------------------------------
INSTALLED=0
LOCAL_IP="" PUB_IP="" TLS=1 ACME=0 PUBLIC_URL="" STALE_INSTALL=0

# The one spelling of the name sslip.io gives an address: a-b-c-d.sslip.io (dashes; the dotted a.b.c.d.sslip.io also
# resolves, but Caddy, ACME, the PBX and every URL printed here must use the same single name).
sslip_name() { printf '%s.sslip.io' "${1//./-}"; }
# A --domain given in the dotted form is the same host: rewrite it to the dashed one.
normalize_sslip_domain() {
  local d="$1"
  if [[ "$d" =~ ^([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\.sslip\.io$ ]]; then
    sslip_name "${BASH_REMATCH[1]}.${BASH_REMATCH[2]}.${BASH_REMATCH[3]}.${BASH_REMATCH[4]}"
  else
    printf '%s' "$d"
  fi
}

# An install counts as initialized once `mpbx init` stored the secrets (in .env, or in the /etc/mpbx copy). Before that
# nothing was started with data in it: a leftover directory is the debris of a failed first install.
install_initialized() {
  [ -n "$(env_get MPBX_MASTER_KEY)" ] && return 0
  grep -q '^MPBX_MASTER_KEY=.' "${MPBX_SECRETS_DIR:-/etc/mpbx}/secrets.env" 2>/dev/null
}

# INSTALLED=1: a real install (converged by this run). STALE_INSTALL=1: the debris of a first install that never got to
# `mpbx init` (replaced as a fresh install, the old directory kept). Neither: a clean machine.
detect_existing_install() {
  [ -f "$PROD/compose.yaml" ] || return 0
  if install_initialized; then
    INSTALLED=1; info "an existing install was found in $ROOT: this run converges it"
  else
    STALE_INSTALL=1
    info "$ROOT holds an earlier install that never finished (no secrets): it is replaced as a fresh install; the old directory is kept as $ROOT.failed-<time>"
  fi
}

# FU-INST-FRONT-NONE-1: --front unset. Fresh install with TLS on: caddy (wss://<host>/sip works out of the box); a re-run
# keeps the earlier choice (front.env present: caddy, else none); no TLS: none.
choose_front() {
  [ -z "$FRONT" ] || return 0
  if [ "$INSTALLED" -eq 1 ]; then
    if [ -f "$PROD/front.env" ]; then FRONT=caddy; else FRONT=none; fi
  elif [ "$TLS" -eq 1 ]; then
    # FU-INST-FRONT-NONE-1: a fresh install serves wss://<host>/sip by default (Caddy front).
    FRONT=caddy; FRONT_DEFAULTED=1
  else
    FRONT=none
  fi
}

preflight() {
  say "Preflight"
  [ "$(uname -s)" = Linux ] || die "this installer runs on Linux (Ubuntu 24.04 LTS) only; it never runs on a workstation"
  [ -r /etc/os-release ] || die "cannot read /etc/os-release"
  local id version_id
  # shellcheck disable=SC1091
  id="$(. /etc/os-release && printf '%s' "${ID:-}")"
  # shellcheck disable=SC1091
  version_id="$(. /etc/os-release && printf '%s' "${VERSION_ID:-}")"
  [ "$id" = ubuntu ] && [ "$version_id" = 24.04 ] || die "unsupported OS ($id $version_id). MonoPbx supports Ubuntu 24.04 LTS only"
  info "OS: Ubuntu 24.04 LTS"
  [ "$(id -u)" -eq 0 ] || die "run as root: curl -fsSL <url>/install.sh | sudo bash"
  case "$(uname -m)" in x86_64|aarch64) info "CPU architecture: $(uname -m)" ;; *) die "unsupported architecture $(uname -m) (amd64 and arm64 only)" ;; esac
  [ -d /run/systemd/system ] || die "systemd is not running as init; the installer needs it for mpbx.service"
  # iproute2 (ip, ss) is part of Ubuntu server images; a minimal image may lack it, and the checks below need it.
  if ! have ip || ! have ss; then
    info "installing iproute2"
    apt-get update -qq && DEBIAN_FRONTEND=noninteractive apt-get install -y -qq iproute2 >/dev/null
  fi
  for c in curl tar sha256sum awk sed getent; do
    have "$c" || die "missing '$c'; install it (apt-get install curl coreutils libc-bin) and run again"
  done

  detect_existing_install

  # Resources
  local cpus ram_kb disk_gb
  cpus="$(nproc)"
  ram_kb="$(awk '/^MemTotal:/ {print $2}' /proc/meminfo)"
  disk_gb="$(df -Pk /var/lib | awk 'NR==2 {print int($4/1024/1024)}')"
  info "CPUs: $cpus, memory: $((ram_kb / 1024)) MiB, free disk under /var/lib: ${disk_gb} GiB"
  if [ "$SKIP_RES" -eq 1 ]; then
    warn "resource minimums skipped (--skip-resource-checks)"
  else
    [ "$cpus" -ge "$MIN_CPUS" ] || die "need at least $MIN_CPUS CPUs, found $cpus"
    [ "$ram_kb" -ge "$MIN_RAM_KB" ] || die "need at least 4 GB of memory, found $((ram_kb / 1024)) MiB"
    [ "$disk_gb" -ge "$MIN_DISK_GB" ] || die "need at least $MIN_DISK_GB GiB free under /var/lib (Docker), found $disk_gb"
  fi

  # The clock (PLAT-INST-009): certificates, ACME, SIP registrations and logs depend on it. A warning, not a stop:
  # many VMs sync a moment after boot. `sudo mpbx-ctl preflight` repeats this and the other host checks later.
  if have timedatectl; then
    case "$(timedatectl show -p NTPSynchronized --value 2>/dev/null || true)" in
      yes) info "clock: synchronised (NTP)" ;;
      no) warn "the clock is not synchronised (NTP): certificates and ACME depend on it. Enable it: timedatectl set-ntp true" ;;
      *) warn "cannot tell whether the clock is synchronised; check NTP" ;;
    esac
  else
    warn "no timedatectl: cannot tell whether the clock is synchronised; check NTP"
  fi
  info "sizing: these are the minimums. For a number of users and calls run: docker run --rm <mpbx image> sizing --users N (docs/guides/preflight-sizing.md)"

  # A terminal is how the recovery key is confirmed.
  if [ "$UNATTENDED" -eq 0 ] && [ "$INSTALLED" -eq 0 ] && [ "$DOCKER_ONLY" -eq 0 ] && ! has_tty; then
    die "no terminal available to confirm the recovery key. Run from a terminal (ssh -t), or pass --unattended and capture the console output safely"
  fi

  # TLS mode: fresh = on; re-run keeps what it had unless told otherwise.
  if [ -z "$TLS_MODE" ]; then
    if [ "$INSTALLED" -eq 1 ] && [ ! -f "$PROD/tls.env" ]; then TLS_MODE=off; else TLS_MODE=on; fi
  fi
  [ "$TLS_MODE" = on ] && TLS=1 || TLS=0
  HTTP_PORT="${HTTP_PORT:-$( [ "$INSTALLED" -eq 1 ] && env_get MPBX_HTTP_PORT || true )}"
  HTTP_PORT="${HTTP_PORT:-8080}"

  # Ports. Our own running stack legitimately holds them.
  local running=0
  if [ "$INSTALLED" -eq 1 ] && systemctl is-active --quiet mpbx.service 2>/dev/null; then running=1; fi
  if [ "$running" -eq 0 ]; then
    local busy=0 p
    local need=("$HTTP_PORT")
    [ "$TLS" -eq 1 ] && need+=(80 443)
    for p in "${need[@]}"; do
      if port_busy tcp "$p"; then warn "TCP port $p is already in use"; busy=1; fi
    done
    [ "$busy" -eq 0 ] || die "free the ports above (or pick another with --http-port, or use --no-tls behind your own proxy) and run again"
    for p in 5060 5061; do port_busy tcp "$p" && warn "TCP port $p is in use; mpbx-sip needs it"; done
    port_busy udp 5060 && warn "UDP port 5060 is in use; mpbx-sip needs it"
  else
    info "ports: skipped, the running mpbx.service holds them"
  fi

  # Addresses
  LOCAL_IP="$(ip -4 route get 1.1.1.1 2>/dev/null | sed -n 's/.* src \([0-9.]*\).*/\1/p' | head -n1 || true)"
  if [ -z "$LOCAL_IP" ]; then
    # Air-gapped LAN without a default gateway: `ip route get` has nothing to answer with. Take the first global address.
    LOCAL_IP="$(ip -4 -o addr show scope global 2>/dev/null | sed -n 's/.* inet \([0-9.]*\)\/.*/\1/p' | head -n1 || true)"
    [ -z "$LOCAL_IP" ] || warn "no default route: using the first global IPv4 address $LOCAL_IP (pass --public-ip to name the address phones use)"
  fi
  [ -n "$LOCAL_IP" ] || die "cannot detect this server's IPv4 address (no default route and no global address)"
  if [ -n "$PUBLIC_IP" ]; then
    PUB_IP="$PUBLIC_IP"
  elif ! is_private_ip "$LOCAL_IP"; then
    PUB_IP="$LOCAL_IP"
  else
    info "private address $LOCAL_IP: asking https://checkip.amazonaws.com for the public one (pass --public-ip to skip)"
    PUB_IP="$(curl -fsS -m 10 --proto '=https' https://checkip.amazonaws.com 2>/dev/null | tr -d '[:space:]' || true)"
    [[ "$PUB_IP" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || { warn "public IP lookup failed; using $LOCAL_IP (pass --public-ip)"; PUB_IP="$LOCAL_IP"; }
  fi
  info "local address: $LOCAL_IP, public address: $PUB_IP"

  # FU-FIX-WSS-PROXY-2: the Caddy front. A re-run keeps it (front.env), and it needs a name: without --domain the
  # public address as <a-b-c-d>.sslip.io (a public wildcard DNS service that answers with the address in the name).
  [ -z "$DOMAIN" ] || DOMAIN="$(normalize_sslip_domain "$DOMAIN")"
  choose_front
  if [ "$FRONT" = caddy ] && [ -z "$DOMAIN" ]; then
    if [ "$INSTALLED" -eq 1 ] && [ -z "$DOMAIN_FLAG" ] && [ -n "$(env_get MPBX_FRONT_SITE)" ]; then
      DOMAIN="$(env_get MPBX_FRONT_SITE)"
    else
      DOMAIN="$(sslip_name "$PUB_IP")"
      info "no --domain: using $DOMAIN (sslip.io resolves it to $PUB_IP)"
    fi
  fi

  # DNS
  if [ -n "$DOMAIN" ]; then
    local resolved
    resolved="$(getent ahostsv4 "$DOMAIN" 2>/dev/null | awk '{print $1}' | sort -u | tr '\n' ' ' || true)"
    if [ -z "$resolved" ]; then
      [ "$SKIP_DNS" -eq 1 ] || die "$DOMAIN does not resolve. Create an A record for $PUB_IP and run again (or --skip-dns-check)"
      warn "$DOMAIN does not resolve yet"
    elif ! grep -qw "$PUB_IP" <<<"$resolved"; then
      [ "$SKIP_DNS" -eq 1 ] || die "$DOMAIN resolves to ${resolved}, not to this server ($PUB_IP). Fix the A record or use --skip-dns-check"
      warn "$DOMAIN resolves to ${resolved}, not to $PUB_IP"
    else
      info "DNS: $DOMAIN -> $PUB_IP"
    fi
  fi

  # ACME needs a name, TLS, and the subscriber agreement.
  if [ "$ACME_TERMS" -eq -1 ]; then
    info "ACME stays off (--no-acme)"
  elif [ -n "$DOMAIN" ] && [ "$TLS" -eq 1 ]; then
    if [ "$ACME_TERMS" -eq 1 ] || ask_explicit "Let ACME ($ACME_DIR) issue a certificate for $DOMAIN? This accepts the CA's subscriber agreement."; then
      ACME=1
    else
      info "ACME stays off: HTTPS serves a self-signed certificate until you request or upload one"
    fi
  elif [ "$ACME_TERMS" -eq 1 ]; then
    warn "--accept-acme-terms needs --domain; ACME stays off"
  elif [ "$TLS" -eq 1 ] && [ "$INSTALLED" -eq 1 ] && grep -q '^MPBX__TLS__ACME_DIRECTORY=.' "$PROD/tls.env" 2>/dev/null; then
    # A re-run without --domain keeps what the earlier run set up.
    ACME=1
    ACME_DIR="$(sed -n 's/^MPBX__TLS__ACME_DIRECTORY=\(.*\)$/\1/p' "$PROD/tls.env" | tail -n1)"
    [ -n "$ACME_EMAIL" ] || ACME_EMAIL="$(sed -n 's/^MPBX__TLS__ACME_CONTACT=\(.*\)$/\1/p' "$PROD/tls.env" | tail -n1)"
    DOMAIN="$(env_get MPBX_PUBLIC_URL | sed -n 's|^https://\([^/:]*\).*$|\1|p')"
    info "ACME stays on as configured before ($DOMAIN)"
  fi

  if [ "$FRONT" = caddy ] && [ "$ACME" -eq 1 ] && [ -z "$ACME_EMAIL" ]; then
    ACME_EMAIL="$(sed -n 's/^MPBX_FRONT_TLS=\(.*@.*\)$/\1/p' "$PROD/.env" 2>/dev/null | tail -n1)"
    [ -n "$ACME_EMAIL" ] || die "--front caddy$([ "$FRONT_DEFAULTED" -eq 1 ] && echo " (the default)") with ACME needs --acme-email (the contact for the certificate); or pass --front none to let mpbx serve 80/443 itself (no wss://<host>/sip)"
  fi
  if [ "$TLS" -eq 1 ]; then PUBLIC_URL="https://${DOMAIN:-$PUB_IP}"; else PUBLIC_URL="http://${DOMAIN:-$PUB_IP}:$HTTP_PORT"; fi
  # A re-run keeps the public URL unless a flag changes it.
  if [ "$INSTALLED" -eq 1 ] && [ -z "$TLS_FLAG_GIVEN" ] && [ -z "$DOMAIN_FLAG" ] && [ -n "$(env_get MPBX_PUBLIC_URL)" ]; then
    PUBLIC_URL="$(env_get MPBX_PUBLIC_URL)"
  fi
}

confirm_plan() {
  echo
  say "Plan"
  info "install dir:    $ROOT (settings and secrets: $PROD/.env, mode 0600)"
  info "public URL:     $PUBLIC_URL"
  [ "$STALE_INSTALL" -eq 0 ] || info "earlier install: $ROOT never finished (no secrets); replaced, the old directory is kept as $ROOT.failed-<time>"
  info "web:            $([ "$TLS" -eq 1 ] && echo "HTTPS 443 and HTTP 80 (ACME challenge + redirect); plain port $HTTP_PORT on 127.0.0.1 only" || echo "plain HTTP $HTTP_PORT (no TLS: put a TLS proxy in front)")"
  info "ACME:           $([ "$ACME" -eq 1 ] && echo "on ($ACME_DIR)" || echo "off")"
  [ "$FRONT" != caddy ] || info "front:          Caddy on 80/443 for $DOMAIN (wss://$DOMAIN/sip), SIP over TLS on 5061"
  info "release:        ${VERSION:-channel $CHANNEL}"
  info "Docker:         installed from Docker's official apt repository if missing"
  if [ "$INSTALLED" -eq 0 ]; then
    info "mpbx init:      will show the RECOVERY KEY once. Have a password manager or paper ready."
  fi
  ask_yes "Continue?" || die "aborted; nothing was changed"
}

# ---- 2. Docker ----------------------------------------------------------------------------------------------------
docker_ok() {
  have docker || return 1
  local cv; cv="$(docker compose version --short 2>/dev/null | sed 's/^v//')" || return 1
  [ -n "$cv" ] || return 1
  local maj min; maj="${cv%%.*}"; min="${cv#*.}"; min="${min%%.*}"
  { [ "$maj" -gt 2 ] || { [ "$maj" -eq 2 ] && [ "$min" -ge 24 ]; }; } || { warn "Docker Compose $cv is older than 2.24"; return 1; }
  local ev; ev="$(docker version --format '{{.Server.Version}}' 2>/dev/null)" || return 1
  [ "${ev%%.*}" -ge 24 ] 2>/dev/null || { warn "Docker Engine $ev is older than 24"; return 1; }
  return 0
}

install_docker() {
  say "Docker"
  if docker_ok; then info "Docker $(docker version --format '{{.Server.Version}}') with Compose $(docker compose version --short) is present"; return; fi
  [ "$AIRGAP" -eq 0 ] || die "--air-gapped: Docker Engine 24+ with the Compose plugin 2.24+ is not installed, and this mode never downloads it. Install the packages you copied to the server (site/docs/operators/air-gapped-install.md, step 3) and run again"
  if have docker && ! docker compose version >/dev/null 2>&1; then
    dpkg -s docker.io >/dev/null 2>&1 && die "Ubuntu's docker.io package is installed without the Compose plugin. Remove it (apt remove docker.io) and run again, or install Docker's compose plugin yourself"
  fi
  export DEBIAN_FRONTEND=noninteractive
  info "installing prerequisites"
  apt-get update -qq
  apt-get install -y -qq ca-certificates curl gnupg iproute2 >/dev/null

  info "fetching Docker's apt signing key and verifying its fingerprint"
  local keytmp; keytmp="$(mktemp)"
  curl -fsSL --proto '=https' --tlsv1.2 "$DOCKER_KEY_URL" -o "$keytmp"
  local fprs; fprs="$(gpg --show-keys --with-colons "$keytmp" 2>/dev/null | awk -F: '$1=="fpr" {print $10}')"
  if ! grep -qx "$DOCKER_KEY_FPR" <<<"$fprs"; then
    rm -f "$keytmp"
    die "the key downloaded from $DOCKER_KEY_URL does not have the expected fingerprint $DOCKER_KEY_FPR; refusing to trust it"
  fi
  install -d -m 0755 /etc/apt/keyrings
  install -m 0644 "$keytmp" /etc/apt/keyrings/docker.asc
  rm -f "$keytmp"
  info "key fingerprint verified: $DOCKER_KEY_FPR"

  cat >/etc/apt/sources.list.d/docker.sources <<EOF
Types: deb
URIs: https://download.docker.com/linux/ubuntu
Suites: noble
Components: stable
Architectures: $(dpkg --print-architecture)
Signed-By: /etc/apt/keyrings/docker.asc
EOF
  apt-get update -qq
  info "installing docker-ce, docker-ce-cli, containerd.io and the compose plugin (packages are signed by that key)"
  apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-compose-plugin >/dev/null
  systemctl enable --now docker.service
  docker_ok || die "Docker was installed but does not pass the version check"
  info "Docker $(docker version --format '{{.Server.Version}}'), Compose $(docker compose version --short)"
}

# ---- 3. bundle ----------------------------------------------------------------------------------------------------
fetch_bundle() {
  say "Release bundle"
  WORK="$(mktemp -d)"
  trap 'rm -rf "$WORK"' EXIT
  local work="$WORK" tarball want=""
  tarball="$work/mpbx-bundle.tar.gz"
  if [ -n "${MPBX_BUNDLE_FILE:-}" ]; then
    [ -f "$MPBX_BUNDLE_FILE" ] || die "MPBX_BUNDLE_FILE does not exist: $MPBX_BUNDLE_FILE"
    cp "$MPBX_BUNDLE_FILE" "$tarball"
    want="${MPBX_BUNDLE_SHA256:-}"
    info "using the local bundle $MPBX_BUNDLE_FILE"
  else
    local base="${MPBX_BASE_URL:-$BASE_URL_DEFAULT}" proto='=https'
    base="${base%/}"
    case "$base" in
      https://*) ;;
      http://127.0.0.1*|http://localhost*|http://\[::1\]*) proto='=https,http' ;;
      *) die "MPBX_BASE_URL must be https:// (http is allowed for loopback only)" ;;
    esac
    local path="$CHANNEL"; [ -z "$VERSION" ] || path="releases/$VERSION"
    info "downloading $base/$path/mpbx-bundle.tar.gz"
    curl -fsSL --proto "$proto" --tlsv1.2 --retry 3 --connect-timeout 15 "$base/$path/mpbx-bundle.tar.gz" -o "$tarball" \
      || die "download failed (the download domain is a placeholder until it is decided: Q-ACCT-03)"
    curl -fsSL --proto "$proto" --tlsv1.2 --retry 3 --connect-timeout 15 "$base/$path/SHA256SUMS" -o "$work/SHA256SUMS" \
      || die "cannot download SHA256SUMS"
    want="${MPBX_BUNDLE_SHA256:-$(awk '$2 == "mpbx-bundle.tar.gz" || $2 == "*mpbx-bundle.tar.gz" {print $1}' "$work/SHA256SUMS")}"
  fi
  [[ "$want" =~ ^[0-9a-f]{64}$ ]] || die "no SHA-256 for the bundle (set MPBX_BUNDLE_SHA256 with MPBX_BUNDLE_FILE)"
  local got; got="$(sha256sum "$tarball" | awk '{print $1}')"
  [ "$got" = "$want" ] || die "bundle checksum mismatch (expected $want, got $got); nothing was installed"
  info "SHA-256 verified: $got"

  # Reject absolute paths and '..' before extracting anything.
  if tar -tzf "$tarball" | grep -Eq '(^/|(^|/)\.\.(/|$))'; then die "the bundle contains unsafe paths"; fi
  mkdir "$work/x"
  tar -xzf "$tarball" -C "$work/x" --no-same-owner
  BUNDLE_DIR="$work/x/mpbx-bundle"
  [ -f "$BUNDLE_DIR/VERSION" ] && [ -f "$BUNDLE_DIR/compose/prod/compose.yaml" ] && [ -f "$BUNDLE_DIR/bin/mpbx-ctl" ] \
    || die "the bundle is incomplete"
  BUNDLE_VERSION="$(tr -d '[:space:]' <"$BUNDLE_DIR/VERSION")"
  info "bundle version: $BUNDLE_VERSION"
}

install_bundle() {
  say "Installing files to $ROOT"
  umask 022
  if [ "$STALE_INSTALL" -eq 1 ] && [ -e "$ROOT" ]; then
    local backup; backup="$ROOT.failed-$(date +%Y%m%dT%H%M%S)"
    # A started-but-failed stack of the old directory must not keep ports or names.
    systemctl stop mpbx.service >/dev/null 2>&1 || true
    [ ! -x "$ROOT/bin/mpbx-ctl" ] || "$ROOT/bin/mpbx-ctl" stop >/dev/null 2>&1 || true
    mv "$ROOT" "$backup" || die "cannot move the unfinished install $ROOT to $backup"
    info "the unfinished earlier install was moved to $backup (no secrets in it; delete it when you like)"
  fi
  if [ -f "$ROOT/VERSION" ]; then
    local have_v; have_v="$(tr -d '[:space:]' <"$ROOT/VERSION")"
    if [ "$have_v" != "$BUNDLE_VERSION" ] && [ "$FORCE_BUNDLE" -eq 0 ]; then
      die "version $have_v is installed and this bundle is $BUNDLE_VERSION. Upgrade with: sudo mpbx-ctl upgrade <bundle> (snapshot and rollback, docs/guides/upgrade-rollback.md); --force-bundle overwrites the files without a snapshot (data and .env are kept)"
    fi
  fi
  install -d -m 0755 "$ROOT" "$ROOT/bin" "$ROOT/compose"
  cp -a "$BUNDLE_DIR/compose/." "$ROOT/compose/"
  install -m 0755 "$BUNDLE_DIR/bin/mpbx-ctl" "$ROOT/bin/mpbx-ctl"
  install -m 0644 "$BUNDLE_DIR/systemd/mpbx.service" "$UNIT.new"
  if [ -f "$BUNDLE_DIR/systemd/mpbx-public-ip.timer" ]; then
    install -m 0644 "$BUNDLE_DIR/systemd/mpbx-public-ip.service" /etc/systemd/system/mpbx-public-ip.service
    install -m 0644 "$BUNDLE_DIR/systemd/mpbx-public-ip.timer" /etc/systemd/system/mpbx-public-ip.timer
  fi
  # FU-DEP05-M1: the host agent of the console rollback button and the state it publishes.
  local u
  for u in mpbx-rollback.path mpbx-rollback.service mpbx-upgrade.path mpbx-upgrade.service mpbx-ctl-state.service mpbx-ctl-state.timer; do
    [ ! -f "$BUNDLE_DIR/systemd/$u" ] || install -m 0644 "$BUNDLE_DIR/systemd/$u" "/etc/systemd/system/$u"
  done
  printf '%s\n' "$BUNDLE_VERSION" >"$ROOT/VERSION"
  # W4-DEP-05: the release manifest `mpbx-ctl upgrade` compares the next release with.
  [ ! -f "$BUNDLE_DIR/release.json" ] || install -m 0644 "$BUNDLE_DIR/release.json" "$ROOT/release.json"
  ln -sfn "$ROOT/bin/mpbx-ctl" "$LINK"
  chmod 0755 "$ROOT/compose/prod/start.sh" "$ROOT/compose/prod/rtpengine/start.sh" 2>/dev/null || true
}

# ---- 4. settings, secrets -----------------------------------------------------------------------------------------
configure() {
  say "Settings"
  umask 077
  [ -f "$PROD/.env" ] || { cp "$PROD/.env.example" "$PROD/.env"; info "created $PROD/.env from .env.example"; }
  chmod 600 "$PROD/.env"

  local img rimg mimg
  img="${MPBX_IMAGE:-$(env_get MPBX_IMAGE)}"
  rimg="${MPBX_RTPENGINE_IMAGE:-$(env_get MPBX_RTPENGINE_IMAGE)}"
  mimg="${MPBX_MEDIA_IMAGE:-$(env_get MPBX_MEDIA_IMAGE)}"
  if [ -f "$BUNDLE_DIR/images.env" ]; then
    [ -n "$img" ] || img="$(sed -n 's/^MPBX_IMAGE=\(.*\)$/\1/p' "$BUNDLE_DIR/images.env" | tail -n1)"
    [ -n "$rimg" ] || rimg="$(sed -n 's/^MPBX_RTPENGINE_IMAGE=\(.*\)$/\1/p' "$BUNDLE_DIR/images.env" | tail -n1)"
    [ -n "$mimg" ] || mimg="$(sed -n 's/^MPBX_MEDIA_IMAGE=\(.*\)$/\1/p' "$BUNDLE_DIR/images.env" | tail -n1)"
  fi
  [ -n "$img" ] && [ -n "$rimg" ] && [ -n "$mimg" ] \
    || die "no image references: the bundle has none and MPBX_IMAGE / MPBX_RTPENGINE_IMAGE / MPBX_MEDIA_IMAGE are not set"
  env_set MPBX_IMAGE "$img"
  env_set MPBX_RTPENGINE_IMAGE "$rimg"
  # MVP-GAP-02: mpbx-media runs as its own service beside rtpengine.
  env_set MPBX_MEDIA_IMAGE "$mimg"
  # The console's update agent (the mpbx-updater service). Optional in an older bundle: compose.yaml then falls back to
  # ghcr.io/ilinaya/monopbx-updater:edge.
  local uimg="${MPBX_UPDATER_IMAGE:-$(env_get MPBX_UPDATER_IMAGE)}"
  if [ -z "$uimg" ] && [ -f "$BUNDLE_DIR/images.env" ]; then
    uimg="$(sed -n 's/^MPBX_UPDATER_IMAGE=\(.*\)$/\1/p' "$BUNDLE_DIR/images.env" | tail -n1)"
  fi
  [ -z "$uimg" ] || env_set MPBX_UPDATER_IMAGE "$uimg"

  # PUBLIC_URL is the existing value on a re-run, unless --domain/--tls/--no-tls changed it (see preflight).
  env_set MPBX_PUBLIC_URL "$PUBLIC_URL"
  # W10-TEN-04: the company base domain. The server stores it once (first start) and every later start uses the
  # stored value, so a re-run without --multi-company leaves it alone.
  if [ "$MULTI_COMPANY" -eq 1 ]; then
    env_set MPBX_BASE_DOMAIN "$DOMAIN"
    info "multi-company: companies at <handle>.$DOMAIN (add the DNS record *.$DOMAIN; certificates: docs/guides/certificates.md)"
  fi
  # The home country the setup wizard preselects (`[setup] country`; the wizard still asks and the API validates it).
  if [ -n "$COUNTRY" ]; then
    env_set MPBX_SETUP_COUNTRY "$COUNTRY"
    info "setup wizard: home country $COUNTRY preselected"
  fi
  env_set MPBX_HTTP_PORT "$HTTP_PORT"
  if [ "$TLS" -eq 1 ]; then env_set MPBX_HTTP_BIND 127.0.0.1; else env_set MPBX_HTTP_BIND 0.0.0.0; fi
  [ -n "$(env_get RTPE_INTERFACE)" ] || env_set RTPE_INTERFACE "$LOCAL_IP"
  configure_ipv6
  configure_rtp_range
  # FU-W4QA01-1: the SIP service (mpbx-sip) tells phones to reach the server under its domain when there is one,
  # else its public address (compose.linux.yaml default). Phones register with this name as their SIP domain.
  if [ -n "$DOMAIN" ]; then env_set MPBX_SIP_ADVERTISE "$DOMAIN"; fi
  if [ "$PUB_IP" != "$LOCAL_IP" ] && [ -z "$(env_get RTPE_ADVERTISE)" ]; then
    env_set RTPE_ADVERTISE "$PUB_IP"
    info "behind NAT: rtpengine advertises $PUB_IP"
  fi
  # The public address and whether it was detected (the 15-minute check updates only a detected one).
  if [ -n "$PUBLIC_IP" ]; then env_set MPBX_PUBLIC_IP_AUTO 0; else env_set MPBX_PUBLIC_IP_AUTO 1; fi
  env_set MPBX_PUBLIC_IP "$PUB_IP"
  configure_bridge_gateway
  configure_turn
  configure_observability
  configure_ims

  # TLS overlay (compose.installer.yaml) is on exactly when tls.env exists.
  if [ "$TLS" -eq 1 ]; then
    {
      echo "# Written by the MonoPbx installer. MPBX__TLS__* only; no secrets. See docs/guides/certificates.md."
      echo "MPBX__TLS__LISTEN=0.0.0.0:8443"
      echo "MPBX__TLS__HTTP_LISTEN=0.0.0.0:8081"
      if [ "$ACME" -eq 1 ]; then
        echo "MPBX__TLS__ACME_DIRECTORY=$ACME_DIR"
        [ -z "$ACME_EMAIL" ] || echo "MPBX__TLS__ACME_CONTACT=$ACME_EMAIL"
        # FU-DEP04-L1: the certificate is requested at the first start; nobody has to sign in first.
        [ -z "$DOMAIN" ] || echo "MPBX__TLS__ACME_REQUEST_DOMAINS=$DOMAIN"
      fi
    } >"$PROD/tls.env"
    chmod 600 "$PROD/tls.env"
    configure_front
    [ "$FRONT" = caddy ] || info "TLS: HTTPS on 443, HTTP on 80 (redirect + ACME challenge); plain port $HTTP_PORT on 127.0.0.1 only"
  else
    rm -f "$PROD/tls.env"
    FRONT=none; configure_front
    warn "TLS is off: the web port $HTTP_PORT is plain HTTP on every interface. Put a TLS proxy in front."
  fi
  configure_media_stream
  # Air-gapped overlay (compose.airgap.yaml) is on exactly when airgap.env exists; a re-run without the flag keeps it.
  if [ "$AIRGAP" -eq 1 ]; then
    printf '%s\n' "# Written by the MonoPbx installer (--air-gapped): mpbx-ctl adds compose.airgap.yaml while this file exists." >"$PROD/airgap.env"
    info "air-gapped: third-party images are used by tag from 'docker load' (compose.airgap.yaml); nothing is pulled"
  fi
  info "the settings are written; secrets are not shown"
}

# The console's update agent, part one: BEFORE the first start. `mpbx-ctl updater enable --no-start` writes the agent's
# settings and the `updater` profile into .env and prepares ctl/ (request key), so the very first `docker compose up`
# creates the mpbx-updater service with the rest of the stack. (Until 2026-11 the agent was enabled only AFTER a
# successful start: a first start that failed or timed out died first and left a running install without it, and the
# console then said "This installation cannot update itself".) Part two is in start_service.
UPDATER_STATE=none   # none (this bundle has no updater service) | prepared | running | failed
prepare_updater() {
  grep -q '^  mpbx-updater:' "$PROD/compose.yaml" 2>/dev/null || return 0
  if "$ROOT/bin/mpbx-ctl" updater enable --no-start; then
    UPDATER_STATE=prepared
  else
    UPDATER_STATE=failed
    warn "could not prepare the mpbx-updater service: after the install run  sudo mpbx-ctl updater enable"
  fi
}

# ADR-0012: IMS mode (VoLTE and VoWiFi) is on in a fresh install. The server default is the same (`[ims] enabled`);
# the value is written to .env so it is visible and `MPBX_IMS_ENABLED=false` (then `mpbx-ctl restart`) turns it off.
# An existing value (a re-run, an upgraded install) is never changed.
configure_ims() {
  [ -n "$(env_get MPBX_IMS_ENABLED)" ] || env_set MPBX_IMS_ENABLED true
  case "$(env_get MPBX_IMS_ENABLED)" in
    false|0|no|off) info "IMS (VoLTE, VoWiFi): off (MPBX_IMS_ENABLED=false in $PROD/.env)" ;;
    *) info "IMS (VoLTE, VoWiFi): on; the ePDG (VoWiFi, UDP 500 and 4500) and the SIM records are set up in the console, Mobile network" ;;
  esac
}

# FU-FIX-WSS-PROXY-2: the Caddy front (compose.front.yaml; on exactly when front.env exists). mpbx's own HTTPS and
# ACME listeners (tls.env, compose.installer.yaml) move to the host's loopback; Caddy owns 80 and 443. front.env holds
# extra MPBX__* settings of mpbx (the push relay); no secrets.
configure_front() {
  if [ "$FRONT" != caddy ]; then
    if [ -f "$PROD/front.env" ]; then
      rm -f "$PROD/front.env"
      env_set MPBX_HTTPS_BIND ""; env_set MPBX_HTTPS_PORT ""; env_set MPBX_ACME_BIND ""; env_set MPBX_ACME_PORT ""
      info "front: Caddy is off again; mpbx serves 80/443 itself"
    fi
    # FU-INST-FRONT-NONE-1: front.env is gone, so mpbx-ctl no longer knows the caddy service; the container of an
    # earlier --front caddy run would keep 80/443 (restart: unless-stopped) and block mpbx. Remove it whatever the
    # state of front.env (idempotent); the certificate volumes (caddy_data, caddy_config) stay.
    remove_caddy_front
    return
  fi
  env_set MPBX_HTTPS_BIND 127.0.0.1
  env_set MPBX_HTTPS_PORT 18443
  env_set MPBX_ACME_BIND 127.0.0.1
  env_set MPBX_ACME_PORT 18081
  env_set MPBX_FRONT_SITE "$DOMAIN"
  if [ "$ACME" -eq 1 ]; then env_set MPBX_FRONT_TLS "$ACME_EMAIL"; else env_set MPBX_FRONT_TLS internal; fi
  local relay_lines=""
  if [ -f "$PROD/front.env" ]; then relay_lines="$(grep -E '^MPBX__RELAY__' "$PROD/front.env" || true)"; fi
  if [ "$NO_RELAY" -eq 1 ]; then
    relay_lines="MPBX__RELAY__ENROLL=false"
  elif [ -n "$RELAY_URL" ]; then
    relay_lines="MPBX__RELAY__URL=$RELAY_URL"
  fi
  {
    echo "# Written by the MonoPbx installer (--front caddy): mpbx-ctl adds compose.front.yaml while this file exists."
    echo "# Extra MPBX__* settings of the mpbx service (no secrets)."
    [ -z "$relay_lines" ] || printf '%s\n' "$relay_lines"
  } >"$PROD/front.env"
  chmod 600 "$PROD/front.env"
  if [ "$ACME" -eq 1 ]; then
    info "front: Caddy on 80/443 for $DOMAIN with a Let's Encrypt certificate (contact $ACME_EMAIL); wss://$DOMAIN/sip"
  else
    info "front: Caddy on 80/443 for $DOMAIN with its own internal CA (browsers warn; no ACME); wss://$DOMAIN/sip"
  fi
  info "SIP over TLS: port 5061 (certificate from the PBX store$([ "$ACME" -eq 1 ] && echo ", ACME for $DOMAIN" || echo ", self-signed until one is uploaded"))"
}

# FU-INST-FRONT-NONE-1: stop and remove the Caddy container of this install (compose label: service caddy, working
# directory $PROD); says so only when there was one.
remove_caddy_front() {
  local ids
  ids="$(docker ps -aq --filter "label=com.docker.compose.service=caddy" \
    --filter "label=com.docker.compose.project.working_dir=$PROD" 2>/dev/null || true)"
  [ -n "$ids" ] || return 0
  # shellcheck disable=SC2086
  docker rm -f $ids >/dev/null 2>&1 || die "could not remove the Caddy front container ($ids); remove it with docker rm -f and run the installer again"
  info "front: stopped and removed the Caddy container of the earlier --front caddy run (ports 80/443 are mpbx's again; certificates stay in the caddy_data volume)"
}

# The SIP engine reads rtpengine's NG address from sip/engine.toml (a list key: no MPBX__ variable can set it), which
# the bundle ships with 172.17.0.1. Rewrite it for the detected gateway (mpbx-ctl repeats this after an upgrade).
apply_bridge_gateway_file() {
  local f="$PROD/sip/engine.toml" gw="$1"
  [ -f "$f" ] || return 0
  grep -q "address = \"$gw:" "$f" && return 0
  sed -i.bak "s|address = \"[0-9.]*:\([0-9]*\)\"|address = \"$gw:\1\"|" "$f" && rm -f "$f.bak"
}

# FU-INST-BRIDGE-1: the host address the bridge containers (the SIP engine, Prometheus) use to reach rtpengine NG and
# mpbx-media, which run on the host network and bind only the Docker bridge gateway (compose.linux.yaml). The default
# 172.17.0.1 is only right for an unmodified daemon: a custom `bip`, a daemon.json default-address-pool or another
# Docker host layout changes it, and the engine then cannot reach the media plane. Detect it (or take
# --bridge-gateway), check it is really an address of this host, and write MPBX_BRIDGE_GATEWAY / MPBX_METRICS_BIND /
# MPBX_BRIDGE_SUBNET to .env.
configure_bridge_gateway() {
  local gw="$BRIDGE_GW" subnet="" how="--bridge-gateway"
  if docker info --format '{{join .SecurityOptions " "}}' 2>/dev/null | grep -q rootless; then
    die "rootless Docker has no host bridge the engine could reach rtpengine through; use the rootful Docker daemon (or --docker-only and a manual layout)"
  fi
  if [ -z "$gw" ]; then
    how="docker network inspect $BRIDGE_NET"
    gw="$(docker network inspect "$BRIDGE_NET" --format '{{range .IPAM.Config}}{{.Gateway}} {{end}}' 2>/dev/null | tr ' ' '\n' | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | head -n1 || true)"
    subnet="$(docker network inspect "$BRIDGE_NET" --format '{{range .IPAM.Config}}{{.Subnet}} {{end}}' 2>/dev/null | tr ' ' '\n' | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/[0-9]+$' | head -n1 || true)"
    [ -n "$gw" ] || die "could not detect the Docker bridge gateway ('docker network inspect $BRIDGE_NET' shows no IPv4 gateway; a custom default bridge network name: --bridge-network NAME); pass --bridge-gateway IP (the address of docker0 on this host, see: ip -4 addr show docker0)"
  fi
  # It must be an address of this host, or rtpengine cannot bind it.
  if have ip && ! ip -4 -o addr show 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | grep -qx "$gw"; then
    die "the Docker bridge gateway $gw ($how) is not an address of this host, so rtpengine cannot bind it; pass the right one with --bridge-gateway IP (ip -4 addr show docker0)"
  fi
  [ -n "$subnet" ] || subnet="$(ip -4 -o addr show 2>/dev/null | awk -v g="$gw" '{split($4,a,"/"); if (a[1]==g) print $4}' | head -n1 || true)"
  # Network address of an interface CIDR (a.b.c.d/n), in plain bash.
  if [ -n "$subnet" ]; then
    local ip="${subnet%/*}" n="${subnet#*/}" a b c d v m
    IFS=. read -r a b c d <<<"$ip"
    v=$(( (a << 24) | (b << 16) | (c << 8) | d ))
    m=$(( n == 0 ? 0 : (0xFFFFFFFF << (32 - n)) & 0xFFFFFFFF ))
    v=$(( v & m ))
    subnet="$(( v >> 24 )).$(( (v >> 16) & 255 )).$(( (v >> 8) & 255 )).$(( v & 255 ))/$n"
  fi
  env_set MPBX_BRIDGE_GATEWAY "$gw"
  env_set MPBX_METRICS_BIND "$gw"
  apply_bridge_gateway_file "$gw"
  env_set MPBX_BRIDGE_SUBNET "${subnet:-172.17.0.0/16}"
  if [ "$gw" = 172.17.0.1 ]; then
    info "docker bridge gateway: $gw (default; $how)"
  else
    info "docker bridge gateway: $gw (NOT the default 172.17.0.1; $how) for the engine to rtpengine and mpbx-media"
  fi
}

# TURN (W4-MED-02, docs/guides/nat-turn.md): coturn on the host network with the shipped deny list, and the URLs
# the API hands to browsers and apps with per-device credentials. TURN over TLS on 443 goes through the HTTPS
# listener of mpbx (only with a domain: clients check the certificate of a turns: URL).
# W10-NET-01: dual-stack media. --ipv6 detects the global IPv6 source address and hands it to rtpengine as a second
# address of the same interface; --no-ipv6 clears it; neither keeps what an earlier run chose.
configure_ipv6() {
  case "$IPV6_MODE" in
    on)
      local v6
      v6="$(ip -6 route get 2001:4860:4860::8888 2>/dev/null | sed -n 's/.* src \([0-9a-fA-F:]*\).*/\1/p' | head -n1 || true)"
      [ -n "$v6" ] || die "--ipv6: this server has no global IPv6 address with a default route"
      env_set RTPE_INTERFACE6 "$v6"
      env_set MPBX_SIP_LISTEN_V6 "[::]:5060"
      info "dual stack: rtpengine also uses $v6 (open the RTP range for IPv6 too)"
      ;;
    off) env_set RTPE_INTERFACE6 ""; env_set MPBX_SIP_LISTEN_V6 "" ;;
    *) : ;;
  esac
}

# FU-W5QA04-3: rtpengine uses 4 UDP ports per relayed call (RTP and RTCP of two legs), so a range of P ports carries
# P / 4 calls. The default 30000-40000 is 2,500 calls, fewer than 4 vCPUs of userspace forwarding carry (about 3,000).
# --calls N sets RTPE_PORT_MAX to 30000 + 4N (rounded up, at least the default). Without it the earlier choice stays.
configure_rtp_range() {
  local min=30000 max
  if [ -n "$CALLS" ]; then
    max=$(( min + 4 * CALLS + 100 ))
    [ "$max" -ge 40000 ] || max=40000
    env_set RTPE_PORT_MIN "$min"
    env_set RTPE_PORT_MAX "$max"
    # FU-GAPB28-3b: the doctor compares sip.max_calls with the range; compose takes the range from RTPE_PORT_MIN/MAX.
    env_set MPBX_SIP_MAX_CALLS "$CALLS"
    info "RTP range $min-$max/udp: about $(( (max - min + 1) / 4 )) concurrent calls (4 ports per call); sip.max_calls = $CALLS"
  else
    max="$(env_get RTPE_PORT_MAX)"; max="${max:-40000}"
    info "RTP range $(env_get RTPE_PORT_MIN | sed 's/^$/30000/')-$max/udp: about $(( (max - ${min}) / 4 )) concurrent calls (--calls N for more)"
  fi
}

configure_turn() {
  local profiles want host
  profiles="$(env_get COMPOSE_PROFILES)"
  if [ -z "$TURN_MODE" ]; then
    case ",$profiles," in *,turn,*) want=on ;; *) want=off ;; esac
  else
    want="$TURN_MODE"
  fi
  # COMPOSE_PROFILES without `turn`, then with it when wanted.
  profiles="$(tr ',' '\n' <<<"$profiles" | grep -v -x -e turn -e '' | paste -sd, - || true)"
  if [ "$want" = off ]; then
    env_set COMPOSE_PROFILES "$profiles"
    env_set MPBX_ICE_STUN_URLS ""
    env_set MPBX_ICE_TURN_URLS ""
    env_set MPBX_ICE_TURN_TLS_FORWARD ""
    info "TURN: off (pass --turn for remote softphones behind strict NAT or firewalls)"
    return
  fi
  env_set COMPOSE_PROFILES "${profiles:+$profiles,}turn"
  # The name clients use: --domain, else the host of the public URL kept from an earlier run, else the address.
  host="${DOMAIN:-$(sed -n 's|^https\{0,1\}://\([^/:]*\).*$|\1|p' <<<"$PUBLIC_URL")}"
  [ -n "$host" ] || host="$PUB_IP"
  env_set TURN_REALM "$host"
  if [ "$PUB_IP" != "$LOCAL_IP" ]; then env_set TURN_EXTERNAL_IP "$PUB_IP/$LOCAL_IP"; else env_set TURN_EXTERNAL_IP ""; fi
  env_set MPBX_ICE_STUN_URLS "stun:$host:3478"
  if [ "$TLS" -eq 1 ] && ! [[ "$host" =~ ^[0-9.]+$ ]]; then
    env_set MPBX_ICE_TURN_URLS "turn:$host:3478?transport=udp turn:$host:3478?transport=tcp turns:$host:443?transport=tcp"
    env_set MPBX_ICE_TURN_TLS_FORWARD "host.docker.internal:3478"
    info "TURN: on (UDP/TCP 3478, and TLS on 443 for clients behind a firewall that allows only 443)"
  else
    env_set MPBX_ICE_TURN_URLS "turn:$host:3478?transport=udp turn:$host:3478?transport=tcp"
    env_set MPBX_ICE_TURN_TLS_FORWARD ""
    info "TURN: on (UDP/TCP 3478). TURN over TLS on 443 needs --domain with a certificate"
  fi
}

# FU-W9-AI-06-5d: the AI media stream listener. The listener is on from the moment .env has MPBX_MEDIA_STREAM_URL
# (mpbx-ctl adds compose.media-stream.yaml); the URL is the Caddy front's site, so no editing of .env by hand.
# A re-run without a flag keeps the earlier choice; without the Caddy front there is no route, so the URL is not kept.
configure_media_stream() {
  local want="$MEDIA_STREAM" cur
  cur="$(env_get MPBX_MEDIA_STREAM_URL)"
  if [ -z "$want" ]; then
    if [ -n "$cur" ] && [ "$FRONT" = caddy ] && [ -n "$DOMAIN" ]; then want=on; else want=off; fi
  fi
  if [ "$want" = on ]; then
    [ "$FRONT" = caddy ] || die "--media-stream needs the Caddy front (the /v1/media-stream route is Caddy's)"
    [ -n "$DOMAIN" ] || die "--media-stream needs the front site name (--domain)"
    env_set MPBX_MEDIA_STREAM_URL "wss://$DOMAIN/v1/media-stream"
    info "media stream: on, clients connect to wss://$DOMAIN/v1/media-stream (ticket from the API; docs/guides/media-app.md)"
    return
  fi
  if [ -n "$cur" ]; then
    env_set MPBX_MEDIA_STREAM_URL ""
    warn "media stream: switched off (it needs the Caddy front; the earlier URL $cur was removed from .env)"
  fi
}

# Optional Prometheus + Grafana (W4-OBS-01, docs/guides/observability.md): the Compose profile `observability`.
# Grafana publishes on 127.0.0.1 only; its admin password is the one `mpbx init` wrote (GRAFANA_ADMIN_PASSWORD).
configure_observability() {
  local profiles want
  profiles="$(env_get COMPOSE_PROFILES)"
  if [ -z "$OBS_MODE" ]; then
    case ",$profiles," in *,observability,*) want=on ;; *) want=off ;; esac
  else
    want="$OBS_MODE"
  fi
  profiles="$(tr ',' '\n' <<<"$profiles" | grep -v -x -e observability -e '' | paste -sd, - || true)"
  if [ "$want" = off ]; then
    env_set COMPOSE_PROFILES "$profiles"
    info "observability: off (pass --observability for Prometheus + Grafana with the MonoPbx dashboards)"
    return
  fi
  env_set COMPOSE_PROFILES "${profiles:+$profiles,}observability"
  info "observability: on (Grafana at http://127.0.0.1:3000 on this host, user admin; password: GRAFANA_ADMIN_PASSWORD in $PROD/.env)"
}

run_init() {
  say "Secrets (mpbx init)"
  if [ -n "$(env_get MPBX_MASTER_KEY)" ]; then
    info "secrets already exist in $PROD/.env: not touched"
    return
  fi
  cd "$PROD"
  export MPBX_UID MPBX_GID COMPOSE_IGNORE_ORPHANS=true
  MPBX_UID="$(id -u)"; MPBX_GID="$(id -g)"
  if [ "$UNATTENDED" -eq 1 ]; then
    warn "unattended: the recovery key is printed ONCE below and cannot be confirmed. Copy it from the console now."
    docker compose -f compose.init.yaml run --rm -T init || die "mpbx init failed; nothing was started. Fix the problem above and run the installer again"
  else
    info "the recovery key is shown next; you will be asked to re-type one group of it"
    docker compose -f compose.init.yaml run --rm init </dev/tty || die "mpbx init did not finish (recovery key not confirmed?): no secrets were written and nothing was started. Run the installer again; a new key will be generated"
  fi
  [ -n "$(env_get MPBX_MASTER_KEY)" ] || die "mpbx init did not store the secrets (recovery key not confirmed?). Nothing was started; run the installer again"
}

# FU-DEP04-L4: second copy of the secrets outside the compose directory (ARCHITECTURE 14.2: /etc/mpbx/secrets.env),
# root only, refreshed on every install run. It survives a deleted or overwritten $PROD/.env on the same host; it is NOT an
# off-host backup (see the summary).
copy_secrets() {
  [ -n "$(env_get MPBX_MASTER_KEY)" ] || return 0
  local dir="${MPBX_SECRETS_DIR:-/etc/mpbx}" tmp
  install -d -m 700 "$dir"
  tmp="$(mktemp "$dir/.secrets.env.XXXXXX")"
  chmod 600 "$tmp"
  cat "$PROD/.env" >"$tmp"
  mv "$tmp" "$dir/secrets.env"
  info "secrets copy:    $dir/secrets.env (0600, root). Also back up $PROD/.env off this host"
}

# ---- 5. service ---------------------------------------------------------------------------------------------------
# `systemctl start|reload mpbx.service` blocks until every container is healthy, which on a first start includes the
# database migrations (hundreds of them, minutes on a small VM). Run it in the background and say what is going on
# every MPBX_PROGRESS_INTERVAL seconds (default 15) instead of staying silent.
run_unit_with_progress() { # run_unit_with_progress start|reload
  local action="$1" pid rc=0 t=0 tick="${MPBX_PROGRESS_INTERVAL:-15}" st
  systemctl "$action" mpbx.service &
  pid=$!
  while kill -0 "$pid" 2>/dev/null; do
    sleep 1
    t=$((t + 1))
    if [ $((t % tick)) -eq 0 ] && kill -0 "$pid" 2>/dev/null; then
      st="$(docker ps -a --filter label=com.docker.compose.service=mpbx --filter "label=com.docker.compose.project.working_dir=$PROD" --format '{{.Status}}' 2>/dev/null | head -n1 || true)"
      info "still starting after ${t}s: the PBX container is ${st:-not created yet}; running database migrations (the first start applies them all, a few minutes on a small server)"
    fi
  done
  wait "$pid" || rc=$?
  return "$rc"
}

start_service() {
  say "Service"
  mv "$UNIT.new" "$UNIT"
  systemctl daemon-reload
  systemctl enable mpbx.service >/dev/null 2>&1
  # The unit is a oneshot that stays "active" (RemainAfterExit), so `start` would not apply changed settings on a
  # re-run. `reload` runs `docker compose up -d --wait`, which recreates only what changed.
  if systemctl is-active --quiet mpbx.service; then
    info "already running: applying the settings (only changed containers are recreated)"
    action=reload
  else
    info "starting: pulling images, then running the database migrations (the first start takes several minutes; waiting up to 25 minutes)"
    action=start
  fi
  run_unit_with_progress "$action" || {
    journalctl -u mpbx.service -n 30 --no-pager >&2 || true
    # The stack may still come up (restart: unless-stopped; the data services were healthy): leave it with its console update agent.
    if [ "$UPDATER_STATE" != none ] && "$ROOT/bin/mpbx-ctl" updater enable >/dev/null 2>&1; then
      info "the mpbx-updater service is running"
    fi
    die "mpbx.service failed to $action (see above; mpbx-ctl logs). Once the PBX is healthy: sudo mpbx-ctl updater enable (the console's Install update)"
  }
  info "mpbx.service is active and enabled"
  if [ -f /etc/systemd/system/mpbx-rollback.path ]; then
    # The request directory and the signing key exist before the path unit watches them.
    "$ROOT/bin/mpbx-ctl" publish-state >/dev/null 2>&1 || warn "could not prepare the console rollback directory"
    systemctl enable --now mpbx-rollback.path mpbx-ctl-state.timer >/dev/null 2>&1 || warn "could not enable the console rollback units"
    # FU-OPS-UI-1: the console's "Install update" button. Preferred: the agent runs INSIDE the stack as the `mpbx-updater`
    # service (`mpbx-ctl updater enable`: .env, the `updater` profile, request key; it also switches the legacy host units
    # off). A bundle without that service falls back to the host unit mpbx-upgrade.path.
    if grep -q '^  mpbx-updater:' "$PROD/compose.yaml" 2>/dev/null; then
      if "$ROOT/bin/mpbx-ctl" updater enable; then
        UPDATER_STATE=running
        info "console updates: the mpbx-updater service is running (no host units)"
      else
        UPDATER_STATE=failed
        warn "could not start the mpbx-updater service (the console cannot start upgrades): sudo mpbx-ctl updater enable"
      fi
      # The agent's units were switched off by `updater enable`; the state file is the console's view.
    elif [ -f /etc/systemd/system/mpbx-upgrade.path ]; then
      systemctl enable --now mpbx-upgrade.path >/dev/null 2>&1 || warn "could not enable mpbx-upgrade.path (the console cannot start upgrades)"
      "$ROOT/bin/mpbx-ctl" publish-state >/dev/null 2>&1 || true
    fi
  fi
  if [ -f /etc/systemd/system/mpbx-public-ip.timer ]; then
    systemctl enable --now mpbx-public-ip.timer >/dev/null 2>&1 || warn "could not enable mpbx-public-ip.timer"
    if [ "$(env_get MPBX_PUBLIC_IP_AUTO)" = 1 ]; then
      info "public address: checked every 15 minutes (mpbx-public-ip.timer); a change updates rtpengine and TURN"
    else
      info "public address: pinned to $PUB_IP (--public-ip); the 15-minute check leaves it alone"
    fi
  fi
}

selftest() {
  say "Selftest"
  "$ROOT/bin/mpbx-ctl" selftest || die "selftest failed. Look at: mpbx-ctl ps; mpbx-ctl logs mpbx"
}

firewall_hints() {
  local fw="" RTP_MIN RTP_MAX
  RTP_MIN="$(env_get RTPE_PORT_MIN)"; RTP_MIN="${RTP_MIN:-30000}"
  RTP_MAX="$(env_get RTPE_PORT_MAX)"; RTP_MAX="${RTP_MAX:-40000}"
  if have ufw && ufw status 2>/dev/null | grep -q "Status: active"; then fw=ufw; fi
  echo
  say "Firewall (open these on this host AND in your cloud security group)"
  cat <<EOF
    80/tcp           ACME challenge and redirect to HTTPS
    443/tcp          web client, API, WebSocket, provisioning
    5061/tcp         SIP over TLS (only with --front caddy)
    500/udp, 4500/udp    VoWiFi: IKEv2 and ESP-in-UDP to the ePDG (IMS mode, on by default). Nothing listens there until the ePDG
                     is set up (docs: guides/ims, The ePDG process); open them only when you use VoWiFi.
    5060/udp, 5060/tcp   SIP (mpbx-sip: phones and trunks register and call here; only your sites' and carriers' addresses if you can)
    ${RTP_MIN}-${RTP_MAX}/udp  RTP media (rtpengine). Without it calls connect but have no audio.
    3478/udp+tcp and 49160-49200/udp        TURN (only with --turn; the relay range is TURN_MIN_PORT-TURN_MAX_PORT)
  Never expose 5432, 6379, 8123, 9000 (databases), 15432, 16379, 18124 (their loopback copies for mpbx-sip) or 22222 (rtpengine NG): the bundle binds none of them beyond this host's loopback.
  With --observability, Grafana listens on 127.0.0.1:3000 of this host only; do not open 3000 (use ssh -L 3000:127.0.0.1:3000).
EOF
  if [ "$fw" = ufw ]; then
    cat <<EOF
  ufw is active here. Example:
    sudo ufw allow 80/tcp && sudo ufw allow 443/tcp
    sudo ufw allow 5060 && sudo ufw allow ${RTP_MIN}:${RTP_MAX}/udp
  Docker-published ports (80, 443) bypass ufw: to restrict them, add rules to the DOCKER-USER chain (Docker never
  rewrites it), for example allow only your office range, then drop the rest:
    sudo iptables -I DOCKER-USER -i <public-interface> -p tcp -m multiport --dports 80,443 -m conntrack --ctstate NEW ! -s <allowed-cidr> -j DROP
  (the rules do not survive a reboot unless saved with iptables-persistent; see docs/guides/vm-installer.md.)
  rtpengine uses the host network, so ufw does govern RTP.
EOF
  else
    info "ufw is not active on this host. If you use another firewall, translate the list above."
  fi
  if [ "$PUB_IP" != "$LOCAL_IP" ]; then
    info "NAT / cloud 1:1: forward the same ports to $LOCAL_IP; rtpengine advertises $PUB_IP."
  fi
}

summary() {
  echo
  say "Done"
  info "web client:      $PUBLIC_URL"
  info "first admin:     open the single-use setup URL that mpbx init printed above ($PUBLIC_URL/setup#token=...)"
  info "                 lost it? run: sudo mpbx-ctl setup-url   (issues a new one, invalidates the old)"
  if [ "$TLS" -eq 1 ]; then
    if [ "$ACME" -eq 1 ]; then
      info "certificate:     HTTPS uses a self-signed certificate until you request the ACME one: after you have created"
      info "                 the administrator, request it in Settings, Certificates (or POST /api/v1/system/certificates/acme"
      info "                 with {\"domains\":[\"$DOMAIN\"]}). Ports 80 and 443 must reach this server."
    else
      info "certificate:     HTTPS uses a self-signed certificate. Upload yours, or re-run with --domain and --accept-acme-terms."
    fi
  fi
  if [ "$FRONT" = caddy ]; then
    info "front:           Caddy on 80/443 for $DOMAIN; web softphone over wss://$DOMAIN/sip; SIP over TLS on $DOMAIN:5061"
  fi
  case "$UPDATER_STATE" in
    running) info "updates:         one-click from the console (Settings, Software update, Install update)" ;;
    none) info "updates:         sudo mpbx-ctl upgrade --channel <stable|nightly> (this bundle has no console update agent)" ;;
    *) info "updates:         NOT one-click yet: sudo mpbx-ctl updater enable (then the console offers Install update); or sudo mpbx-ctl upgrade --channel <stable|nightly>" ;;
  esac
  case "$(env_get MPBX_IMS_ENABLED)" in
    false|0|no|off) info "IMS:             off (MPBX_IMS_ENABLED=false); on by default: remove it or set true, then sudo mpbx-ctl restart" ;;
    *) info "IMS:             on (VoLTE and VoWiFi settings in the console, Mobile network; MPBX_IMS_ENABLED=false in $PROD/.env turns it off)" ;;
  esac
  info "manage:          sudo mpbx-ctl status | logs | selftest | restart | uninstall"
  info "back up:         COPY $PROD/.env (or ${MPBX_SECRETS_DIR:-/etc/mpbx}/secrets.env) OFF this host together with the Docker volumes."
  info "                 Without it the data cannot be decrypted except with the recovery key. Keep the recovery key off this host too."
}

main() {
  # `install.sh uninstall ...` has its own options and is handled by mpbx-ctl.
  if [ "${1:-}" = uninstall ]; then
    shift
    [ -x "$ROOT/bin/mpbx-ctl" ] || die "no install found in $ROOT"
    exec "$ROOT/bin/mpbx-ctl" uninstall "$@"
  fi
  parse_args "$@"
  preflight
  confirm_plan
  install_docker
  if [ "$DOCKER_ONLY" -eq 1 ]; then say "Docker is ready (--docker-only): stopping here"; exit 0; fi
  fetch_bundle
  install_bundle
  configure
  prepare_updater
  run_init
  copy_secrets
  start_service
  selftest
  firewall_hints
  summary
}

# MPBX_INSTALLER_SOURCE_ONLY=1 lets deploy/installer/test/front-bridge-test.sh load the functions.
[ -n "${MPBX_INSTALLER_SOURCE_ONLY:-}" ] || main "$@"
